<?php
$themeName = 'eLavenn';

$themeFolder = 'elavenn';

$themeAuthor = 'Teja Sundeep';

$themeAuthorUrl = 'mailto:tsreddykarri@gmail.com';

$themeVirsion = '1.0';

$themeImg = $themeFolder . '/themeLogo.png';
?>