<?php
$themeName = 'WoWonder';

$themeFolder = 'wowonder';

$themeAuthor = 'Deen Doughouz';

$themeAuthorUrl = 'mailto:wowondersocial@gmail.com';

$themeVirsion = '2.5';

$themeImg = $themeFolder . '/themeLogo.png';
?>